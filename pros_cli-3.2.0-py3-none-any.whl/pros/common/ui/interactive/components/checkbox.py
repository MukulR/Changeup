from pros.common.ui.interactive.components.component import BasicParameterizedComponent
from pros.common.ui.interactive.parameters import BooleanParameter


class Checkbox(BasicParameterizedComponent[BooleanParameter]):
    pass
